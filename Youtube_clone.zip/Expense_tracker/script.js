// script.js
const balance = document.getElementById('balance');
const text = document.getElementById('text');
const amount = document.getElementById('amount');
const form = document.getElementById('expense-form');
const expenseList = document.getElementById('expense-list');

let totalBalance = 0;

function addExpense(description, amountValue) {
  const sign = amountValue < 0 ? '-' : '+';
  const expense = document.createElement('li');
  expense.innerHTML = `
    ${description} <span>${sign}$${Math.abs(amountValue)}</span>
    <button class="delete-btn">x</button>
  `;
  expenseList.appendChild(expense);
  totalBalance += amountValue;
  updateBalance();
}

function updateBalance() {
  balance.textContent = `$${totalBalance.toFixed(2)}`;
}

function deleteExpense(target) {
  const listItem = target.parentElement;
  const amountString = listItem.textContent.split('$')[1];
  const amountValue = parseFloat(amountString) || 0;
  listItem.remove();
  totalBalance -= amountValue;
  updateBalance();
}

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const description = text.value.trim();
  const amountValue = parseFloat(amount.value);
  if (description !== '' && !isNaN(amountValue)) {
    addExpense(description, amountValue);
    text.value = '';
    amount.value = '';
  } else {
    alert('Please enter valid description and amount.');
  }
});

expenseList.addEventListener('click', (e) => {
  if (e.target.classList.contains('delete-btn')) {
    deleteExpense(e.target);
  }
});
