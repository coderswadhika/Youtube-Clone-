


Cloud_pct:
Feels_like:
Humidity:
Max_temp:
Min_temp:
Sunrise:
Sunset:
Temp:
Wind_degrees:
Wind_speed: